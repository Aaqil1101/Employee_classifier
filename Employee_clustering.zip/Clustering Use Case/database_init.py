import pandas as pd
import numpy as np
from tqdm import tqdm
import sqlite3

cols = ['Technical Skills', 'Domain Expertise', 'Years of Experience',
        'Project Complexity', 'Learning Agility',
        'Quality of Work', 'Efficiency', 'Problem-Solving Skills',
        'Client Satisfaction', 'Deliverables Consistency',
        'Teamwork', 'Communication Skills', 'Leadership',
        'Mentorship', 'Collaboration Tools',
        'Strategic Thinking', 'Business Impact', 'Client Relationship Management',
        'Industry Knowledge', 'Innovation & Initiative',
        'Customer Focused', 'Result Oriented', 'Adaptable',
        'Opportunistic', 'Overall']

def random_fill(rows, cols):
    rng = np.random.RandomState(42)
    pos_list = ['Intern', 'ATC', 'TC', 'LTC', 'TA', 'STA', 'TL']
    range_dict = {'Intern': [1,6], 'ATC': [1,6], 'TC': [1,6],
                  'LTC': [1,5], 'TA': [1,5], 'STA': [1,5], 'TL': [1,5]}
    def random_based_on_column(row):
        value = row['Position']
        return rng.randint(*range_dict[value])
    df = pd.DataFrame()
    df['Emp_ID'] = ['{:06d}'.format(x) for x in range(1, rows+1)]
    df['Position'] = rng.choice(pos_list, size=100000)
    
    for i in tqdm(range(len(cols))):
        df[cols[i]] = df.apply(random_based_on_column, axis=1)
    return df
tdf = random_fill(100000, cols)
print(tdf.head())
conn = sqlite3.connect('emp_data.db')
tdf.to_sql(name='emp_performance', con=conn, if_exists='replace', index=False)
conn.commit()
conn.close()