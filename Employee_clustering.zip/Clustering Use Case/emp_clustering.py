print("Importing required packages...")

import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import sqlite3

query_dict = {}
df_dict = {}

print("Waiting for connection to database...")
conn = sqlite3.connect('emp_data.db')

query_dict[0] = "SELECT * FROM emp_performance where Position='Intern'"
query_dict[1] = "SELECT * FROM emp_performance where Position='ATC'"
query_dict[2] = "SELECT * FROM emp_performance where Position='TC'"
query_dict[3] = "SELECT * FROM emp_performance where Position='LTC'"
query_dict[4] = "SELECT * FROM emp_performance where Position='TA'"
query_dict[5] = "SELECT * FROM emp_performance where Position='STA'"
query_dict[6] = "SELECT * FROM emp_performance where Position='TL'"

for i in query_dict:
    df_dict[i] = pd.read_sql_query(query_dict[i], conn)

conn.close()
print("Data has been queried, connection terminated!")
print("Clustering employees...")
scaler = MinMaxScaler(feature_range=(1, 2))
columns_to_scale = df_dict[0].columns[2:]
for i in df_dict:
    tdf = df_dict[i].drop(columns = ['Position'])
    tdf[columns_to_scale] = scaler.fit_transform(tdf[columns_to_scale])
    df_dict[i] = tdf


#print(df_dict[0].columns)
#print(len(df_dict[0].columns))
#print(df_dict[0].describe())

w_dict = {}
w_dict[0] = [
    3, 1, 1, 1, 4, 
    4, 2, 3, 0, 4, 
    2, 2, 0, 0, 2, 
    1, 0, 0, 1, 3, 
    0, 4, 4, 1, 5]
w_dict[1] = [
    3, 2, 1, 2, 4, 
    4, 3, 3, 2, 4, 
    3, 3, 1, 1, 2, 
    2, 0, 0, 2, 3, 
    2, 4, 4, 2, 5]
w_dict[2] = [
    4, 3, 2, 3, 4, 
    5, 4, 4, 3, 5, 
    4, 4, 2, 2, 3, 
    3, 0, 0, 3, 4, 
    3, 4, 4, 4, 5]
w_dict[3] = [
    4, 4, 3, 4, 3, 
    5, 4, 5, 4, 5, 
    4, 4, 4, 3, 4, 
    4, 0, 0, 4, 4, 
    4, 5, 4, 4, 5]
w_dict[4] = [
    4, 4, 4, 4, 2, 
    5, 4, 5, 4, 5, 
    4, 4, 4, 4, 4, 
    5, 4, 0, 4, 5, 
    4, 5, 4, 4, 5]
w_dict[5] = [
    5, 5, 5, 5, 1, 
    5, 5, 5, 4, 5, 
    4, 4, 5, 5, 4, 
    5, 5, 0, 5, 4, 
    4, 5, 4, 5, 5]
w_dict[6] = [
    4, 3, 3, 4, 3, 
    5, 4, 5, 4, 5, 
    5, 5, 5, 4, 3, 
    4, 4, 4, 4, 4, 
    4, 5, 4, 1, 5]



def cluster_data(data, weights):
    centers = [[],[],[],[]]
    for i in weights:
        diff = i
        centers[0].append(i+diff/8)
        centers[1].append(i+3*diff/8)
        centers[2].append((i+diff)-3*diff/8)
        centers[3].append((i+diff)-diff/8)
    for i,j in zip(data.columns[1:], weights):
        data[i] = data[i]*j
    kmeans = KMeans(n_clusters=4, init=centers, n_init=1, max_iter=1)  
    kmeans.fit(data[data.columns[1:]])
    data['cluster'] = kmeans.labels_
    return data

pos_dict = {
    0:'Intern', 1:'ATC', 2:'TC',3:'LTC', 4:'TA', 5:'STA', 6:'TL'}

fig, axes = plt.subplots(2, 4, figsize=(12, 12))
for i in df_dict:
    print(pos_dict)
    df_dict[i] = cluster_data(df_dict[i], w_dict[i])
    df_dict[i].loc[df_dict[i]['cluster']==0,'cluster'] = 'R'
    df_dict[i].loc[df_dict[i]['cluster']==1,'cluster'] = 'A'
    df_dict[i].loc[df_dict[i]['cluster']==2,'cluster'] = 'C'
    df_dict[i].loc[df_dict[i]['cluster']==3,'cluster'] = 'E'
    print(df_dict[i]['cluster'].value_counts())

    ax = axes.flat[i]
    labels = df_dict[i]['cluster'].value_counts().index.to_numpy()
    data = df_dict[i]['cluster'].value_counts().to_numpy()

    wedges, texts, autotexts = ax.pie(data, labels=labels, autopct="%1.1f%%", startangle=170, pctdistance=0.85)
    for text in texts:
        text.set_fontsize(10)
    for autotext in autotexts:
        autotext.set_fontsize(8)
    ax.set_title("Distribution of "+pos_dict[i]+"s")
fig.delaxes(axes[1, 3])
plt.tight_layout()
print("Employees have been clustered by position, showing charts...")
plt.show()

print("Saving clustered data to database...")
conn = sqlite3.connect('emp_data.db')

for i in df_dict:
    n = pos_dict[i]+"_clustered"
    df_dict[i].to_sql(name = n, con=conn, if_exists='replace', index=False)
    print("Cluster of "+pos_dict[i]+"s has been saved to table: "+n)
conn.commit()
conn.close()
print("Tables have been commited, execution complete!")