import sys
import subprocess
packages = ['joblib', 'pandas', 'scikit-learn', 'PyPDF2']
for i in packages:
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', i])