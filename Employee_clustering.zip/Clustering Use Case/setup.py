import sys
import subprocess
packages = ['numpy', 'pandas', 'scikit-learn', 'tqdm', 'matplotlib']
print("Installing additional packages...")
for i in packages:
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', i])
print('Additional packages installed successfully!')